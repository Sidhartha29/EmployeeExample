import EmployeePanel from './components/EmployeePanel';

function App() {
  return (
    <div className="App">
      <EmployeePanel />
    </div>
  );
}

export default App;
