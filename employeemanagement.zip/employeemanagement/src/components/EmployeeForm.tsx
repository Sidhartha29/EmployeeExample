import { useState } from 'react';
import { addEmployee } from '../api/api';

const EmployeeForm = ({ onAdd }: { onAdd: () => void }) => {
  const [name, setName] = useState('');
  const [salary, setSalary] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await addEmployee({ name, salary: parseFloat(salary) });
    onAdd();
    setName('');
    setSalary('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input value={name} onChange={e => setName(e.target.value)} placeholder="Name" required />
      <input value={salary} onChange={e => setSalary(e.target.value)} placeholder="Salary" type="number" required />
      <button type="submit">Add Employee</button>
    </form>
  );
};

export default EmployeeForm;
