import { Employee } from '../types/models';

const EmployeesTable = ({ employees }: { employees: Employee[] }) => (
  <table>
    <thead>
      <tr>
        <th>ID</th><th>Name</th><th>Salary</th>
      </tr>
    </thead>
    <tbody>
      {employees.map(emp => (
        <tr key={emp.id}>
          <td>{emp.id}</td>
          <td>{emp.name}</td>
          <td>{emp.salary}</td>
        </tr>
      ))}
    </tbody>
  </table>
);

export default EmployeesTable;
