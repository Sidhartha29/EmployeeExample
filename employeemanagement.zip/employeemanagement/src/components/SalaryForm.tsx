import { useState } from 'react';

interface Props {
  onSubmit: (salary: number) => void;
}

export default function SalaryForm({ onSubmit }: Props) {
  const [salary, setSalary] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const value = parseFloat(salary);
    if (!isNaN(value) && value > 0) {
      onSubmit(value);
      setSalary('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-2">
      <input
        type="number"
        value={salary}
        onChange={(e) => setSalary(e.target.value)}
        placeholder="Salary"
        required
      />
      <button type="submit">Add Employee</button>
    </form>
  );
}
