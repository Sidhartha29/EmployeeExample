import { useEffect, useState } from 'react';
import { getEmployees } from '../api/api';
import { Employee } from '../types/models';
import EmployeeForm from './EmployeeForm';
import EmployeesTable from './EmployeeTable';

const EmployeePanel = () => {
  const [employees, setEmployees] = useState<Employee[]>([]);

  const fetchEmployees = async () => {
    const data = await getEmployees();
    setEmployees(data);
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  return (
    <div>
      <h2>Employee Management</h2>
      <EmployeeForm onAdd={fetchEmployees} />
      <EmployeesTable employees={employees} />
    </div>
  );
};

export default EmployeePanel;
