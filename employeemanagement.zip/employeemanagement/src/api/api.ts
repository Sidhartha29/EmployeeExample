import axios from 'axios';
import { Employee } from '../types/models';

const BASE_URL = 'http://localhost:8085/api/employees';

export const getEmployees = async (): Promise<Employee[]> => {
  const response = await axios.get(BASE_URL);
  return response.data;
};

export const addEmployee = async (employee: Omit<Employee, 'id'>): Promise<Employee> => {
  const response = await axios.post(BASE_URL, employee);
  return response.data;
};
